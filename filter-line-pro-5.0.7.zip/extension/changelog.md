# Change Log
All notable changes to the "filter-line" extension will be documented in this file.


## [1.5.x]
- Filter history : https://github.com/everettjf/vscode-filter-line/pull/16  (Thanks to https://github.com/GOST-UA )

## [1.4.x]
- Add context menu : https://github.com/everettjf/vscode-filter-line/pull/14 (Thanks to https://github.com/GOST-UA )

## [1.3.x]
- Support large file filter : https://github.com/everettjf/vscode-filter-line/issues/10

## [1.2.x]
- Fix issue : https://github.com/everettjf/vscode-filter-line/issues/6

## [1.1.x]
- Bug fixed

## [1.0.x]
- Many bugs fixed

## [0.9.x]
- Initial release