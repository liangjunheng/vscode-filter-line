#npm install

vsce package
vsce publish patch